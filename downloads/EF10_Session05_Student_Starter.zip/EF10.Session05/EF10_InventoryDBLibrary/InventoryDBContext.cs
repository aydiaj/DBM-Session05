using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;

namespace EF10_InventoryDBLibrary;

public class InventoryDbContext : DbContext
{
    public InventoryDbContext(DbContextOptions<InventoryDbContext> options)
        : base(options)
    {
    }

    // TODO 02 - Expose the Items DbSet property here.
}
