using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EF10_InventoryModels;

public class Item
{
    public int Id { get; set; }

    // TODO 01A - Add Required and StringLength(100) above Name.
    public string Name { get; set; } = "";

    // TODO 01B - Map UnitPrice to decimal(10,2) with Column.
    public decimal UnitPrice { get; set; }

    public int Stock { get; set; }
    public bool IsActive { get; set; }
    public DateTime AddedAt { get; set; }
}
