# Session 05 - student starter

1. Extract the ZIP. Open EF10InventoryManager.sln in Visual Studio with .NET 10 support.
2. In SSMS, connect to your SQL Server instance and run setup-inventory.sql, then verify-inventory.sql. Fresh setup has 16 rows and 13 active items. Existing rows are kept.
3. Set EF10_InventoryManager as the startup project. Restore NuGet packages.
4. TODO 00: replace YOUR_SERVER in EF10_InventoryManager/appsettings.json with the instance used in SSMS. For SQLEXPRESS, JSON needs two backslashes: .\\SQLEXPRESS. Keep Database=DBM_Session05_Inventory.
5. Complete TODO 01 in the model library, TODO 02 in the database library, then TODOs 03-04 in Program.cs. Run the baseline.
6. Complete TODOs 05-11 as the codelab introduces each query family. Each block uses distinct variable names and belongs inside the existing try block.

The starter builds before the TODOs, once packages restore. It initially prints a setup message. The existing model properties and display helper are supplied; you complete mapping attributes, DbSet, provider configuration and queries. ConsoleReport.cs holds the supplied PrintItems method. The using static directive in Program.cs makes that method available by its short name.

The Console project references the database Class Library, which references the model Class Library. These references are prepared. A Class Library builds a reusable DLL; it does not start its own Console application.

CLI alternative, from this folder:

```sh
dotnet restore EF10InventoryManager.sln
dotnet run --project EF10_InventoryManager
```

The supplied connection string uses Windows authentication and a trusted classroom certificate. Copy your own server name. If SQL authentication is needed, your instructor can supply the DBM_EF05_CONNECTION environment override; keep passwords out of submitted files. The override takes precedence over appsettings.json. It is specific to Session 05.

Packages retain the working Session 04 configuration: EF Core SQL Server 10.0.14, Configuration.Json 10.0.14 and the direct System.Security.Cryptography.Pkcs 10.0.13 dependency. The cryptography dependency's version is not an EF Core version instruction. The model library uses framework DataAnnotations/Schema attributes and does not need an extra EF package.

This is an existing-database exercise with manually written mapping. Creating the context does not open a connection. Query execution tests the server/mapping. No SaveChanges or migrations are required here. Do not change Session 04's database.

Expected data and complete line explanations are in CODE-EXPLAINED.md. Use the codelab's hints and reveal solutions after an attempt.
