using EF10_InventoryDBLibrary;
using EF10_InventoryModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;
using System.Globalization;
using static EF10_InventoryManager.ConsoleReport;

// Supplied: use the same decimal format in each classroom report.
CultureInfo.CurrentCulture = CultureInfo.InvariantCulture;
Console.WriteLine("DBM Session 05 - EF Core recap and LINQ practice");

try
{
    // Supplied configuration loader. Set the server in appsettings.json (TODO 00).
    var configuration = new ConfigurationBuilder()
        .SetBasePath(AppContext.BaseDirectory)
        .AddJsonFile("appsettings.json", optional: false)
        .Build();
    string? connectionString = Environment.GetEnvironmentVariable("DBM_EF05_CONNECTION")
        ?? configuration.GetConnectionString("InventoryDbConnection");
    if (string.IsNullOrWhiteSpace(connectionString) || connectionString.Contains("YOUR_SERVER"))
    {
        Console.WriteLine("Complete TODO 00 in appsettings.json. No database request was made.");
        return;
    }

    // TODO 03 START - Configure the provider, options and context
    Console.WriteLine("Complete TODO 03 to create the context.");
    // TODO 03 END

    // TODO 04 START - Q0 - Read the alphabetical inventory
    // Write your code here. Keep it inside this try block.
    // TODO 04 END

    // TODO 05 START - Q1 - Active items with stock
    // Write your code here. Keep it inside this try block.
    // TODO 05 END

    // TODO 06 START - Q2 - Search, including the blank-input policy
    // Write your code here. Keep it inside this try block.
    // TODO 06 END

    // TODO 07 START - Q3 - Stock and price range
    // Write your code here. Keep it inside this try block.
    // TODO 07 END

    // TODO 08 START - Q4 - Sort and project
    // Write your code here. Keep it inside this try block.
    // TODO 08 END

    // TODO 09 START - Q5 - Count and existence
    // Write your code here. Keep it inside this try block.
    // TODO 09 END

    // TODO 10 START - Q6 - Find one item or handle absence
    // Write your code here. Keep it inside this try block.
    // TODO 10 END

    // TODO 11 START - Q7 - Independent report
    // Write your code here. Keep it inside this try block.
    // TODO 11 END
}
catch (SqlException ex)
{
    Console.WriteLine($"SQL Server error {ex.Number}: {ex.Message}");
    Console.WriteLine("Check the instance, authentication and Session 05 setup script in SSMS.");
}
catch (InvalidOperationException ex)
{
    Console.WriteLine($"EF Core model/configuration error: {ex.Message}");
    Console.WriteLine("Check the entity key, Items DbSet, SQL Server provider and options.");
}
catch (ArgumentException ex)
{
    Console.WriteLine($"Connection/options error: {ex.Message}");
}
catch (System.IO.IOException ex)
{
    Console.WriteLine($"Configuration file error: {ex.Message}");
}
