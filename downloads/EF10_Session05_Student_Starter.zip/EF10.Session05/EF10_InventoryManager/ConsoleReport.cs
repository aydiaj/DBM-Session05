using EF10_InventoryModels;

namespace EF10_InventoryManager;

// Supplied display helper. It reads the loaded list; it does not query SQL Server.
internal static class ConsoleReport
{
    internal static void PrintItems(string title, List<Item> items)
    {
        Console.WriteLine($"\n{title}");
        Console.WriteLine("Id | Name | UnitPrice | Stock | IsActive");
        foreach (Item item in items)
        {
            Console.WriteLine($"{item.Id} | {item.Name} | {item.UnitPrice:F2} | {item.Stock} | {item.IsActive}");
        }
        Console.WriteLine($"Rows: {items.Count}");
        if (items.Count == 0)
            Console.WriteLine("No items matched.");
    }
}
